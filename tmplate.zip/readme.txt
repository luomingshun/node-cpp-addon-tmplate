发布说明

1） 复制publicConfig/下面对应操作系统的package.json，package-lock.json到项目根目录
2） 命令行进入项目根目录
2） 执行nmp install 安装依赖
3） 执行 npm run rebuild 构建插件 （如果未安装electron-rebuild，先执行 npm install --save-dev electron-rebuild）
4） 执行 npm publish 发布