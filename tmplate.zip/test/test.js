var ins=require("../dist/$$PROJECT_NAME$$")

ins.printMsg("Hello,World",function(ok){
	console.log("Test Result:",ok)
})