#ifndef __COMMON_TEMPLATE_H_
#define __COMMON_TEMPLATE_H_
#include<mutex>
#include<memory>
#include"GlobalDefs.h"


#define COMMON_NULL_SHARED_PTR(T) (shared_ptr<T>(nullptr))
#define MAX_HANDLES_NUM			  128

template<class T>
class SingletonClassBase {
public:
	static T * getSingletone(void);

	SingletonClassBase(const SingletonClassBase &) = delete;
	SingletonClassBase& operator== (const SingletonClassBase &) = delete;
protected:
	SingletonClassBase()
	{
	}
	virtual ~SingletonClassBase()
	{

	}
private:
	static T* mInstance;
	static std::mutex mLock;
};
template <class T>
T* SingletonClassBase<T>::mInstance = nullptr;
template <class T>
std::mutex SingletonClassBase<T>::mLock;
template <class T>
T * SingletonClassBase<T>::getSingletone(void)
{
	//std::lock_guard<mutex> lock(mLock); //program crash,need check

	if (mInstance == nullptr) {
		mInstance = new T();
	}

	return mInstance;
}

template <class T>
class HandleManager: public SingletonClassBase<HandleManager<T>> {
public:
	friend class SingletonClassBase<HandleManager<T>>;
#define NULL_SHARED_PTR_T COMMON_NULL_SHARED_PTR(T)
	int put(shared_ptr<T> &t)
	{
		int ret = -1;

		std::lock_guard<mutex> lock(mMutex);

		for (int i = 0; i < ARRAY_SIZE(mHandles); i++)
		{
			if (!mHandles[i])
			{
				mHandles[i] = t;
				ret = i;
				break;
			}
		}
		
		return ret;
	}
	shared_ptr<T> get(int i)
	{
		shared_ptr<T> ret = NULL_SHARED_PTR_T;

		std::lock_guard<mutex> lock(mMutex);

		if (i >= 0 && i < ARRAY_SIZE(mHandles))
		{
			ret = mHandles[i];
		}

		return ret;
	}
	void set(int i, shared_ptr<T> t)
	{
		std::lock_guard<mutex> lock(mMutex);

		if (i >= 0 && i < ARRAY_SIZE(mHandles))
		{
			mHandles[i] = t;
		}
		
	}
	void free(int i)
	{
		std::lock_guard<mutex> lock(mMutex);

		if (i >= 0 && i < ARRAY_SIZE(mHandles))
		{
			mHandles[i] = nullptr;
		}
		
	}
private:
	HandleManager()
	{
		for (int i = 0; i < ARRAY_SIZE(mHandles); i++)
		{
			mHandles[i] = NULL_SHARED_PTR_T;
		}
	}
	
	shared_ptr<T> mHandles[MAX_HANDLES_NUM];

	std::mutex mMutex;
};
#endif
