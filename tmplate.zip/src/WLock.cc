#include "wlock.h"

WLock::WLock()
{
	
}

WLock::~WLock()
{
	
}

void WLock::Lock()
{
	mMutex.lock();
}

void WLock::UnLock()
{
	mMutex.unlock();
}

WAutoLock::WAutoLock( WLock* pLock ):m_pLock( pLock )
{
	if( m_pLock )
		m_pLock->Lock();
}

WAutoLock::~WAutoLock()
{
	if( m_pLock )
		m_pLock->UnLock();
}
