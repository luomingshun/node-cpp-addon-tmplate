#ifndef __REF_CLASS__HPP__
#define __REF_CLASS__HPP__

#include "WLock.h"

class RefClass{
public:
    RefClass();
    virtual ~RefClass();

    void ref(void);
    void unref(void);
    int lock(void);
    int unlock(void);
private:
    WLock mLock;
    int mRefCount;
};
#endif