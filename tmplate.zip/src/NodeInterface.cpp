#include<stdio.h>
#include<mutex>
#include<iostream>
#include <v8.h>
#include <node.h>
#include <node_buffer.h>
#include <thread>
#include "GlobalDefs.h"
#include "AsyncTask.hpp"
#include"CommonTemplates.h"

using namespace v8;
using namespace node;

//macors
#define MAX_EXCEPT_MSG_LEN			256

#define CHECK_ATTRIB(attri,name,member)\
	if(!attri->Has(String::NewFromUtf8(isolate, member)))\
	{\
		char msg[MAX_EXCEPT_MSG_LEN];\
		snprintf(msg,sizeof(msg),"%s: %s has no attribute:%s",__FUNCTION__,name,member);\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, msg)));\
		return;\
	}

#define CHECK_IS_NUMBER(arg,name)\
	if(!arg->IsNumber())\
	{\
		char msg[MAX_EXCEPT_MSG_LEN];\
		snprintf(msg,sizeof(msg),"%s:%s is not number",__FUNCTION__,name);\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, msg)));\
		return;\
	}

#define CHECK_ARGS_IS_NUMBER(index) CHECK_IS_NUMBER(args[index],"args "#index)

#define CHECK_IS_STRING(arg,name)\
	if(!arg->IsString())\
	{\
		char msg[MAX_EXCEPT_MSG_LEN];\
		snprintf(msg,sizeof(msg),"%s:%s is not String",__FUNCTION__,name);\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, msg)));\
		return;\
	}

#define CHECK_ARGS_IS_STRING(index) CHECK_IS_STRING(args[index],"args "#index)

#define CHECK_IS_OBJECT(arg,name)\
	if(!arg->IsObject())\
	{\
		char msg[MAX_EXCEPT_MSG_LEN];\
		snprintf(msg,sizeof(msg),"%s:%s is not Object",__FUNCTION__,name);\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, msg)));\
		return;\
	}

#define CHECK_ARGS_IS_OBJECT(index) CHECK_IS_OBJECT(args[index],"args "#index)

#define CHECK_IS_FUNCTION(arg,name)\
	if(!arg->IsObject())\
	{\
		char msg[MAX_EXCEPT_MSG_LEN];\
		snprintf(msg,sizeof(msg),"%s:%s is not Function",__FUNCTION__,name);\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, msg)));\
		return;\
	}

#define CHECK_ARGS_IS_FUNCTION(index) CHECK_IS_FUNCTION(args[index],"args "#index)

#define CHECK_ARGS_LENGTH(len)\
	if(args.Length() < len)\
	{\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, __FUNCTION__":""Param Length Error")));\
		return;\
	}
//tips must be string,not variable
#define CHECK_THTOW_EXCEPTION(con,tips)\
	if (!(con))\
	{\
		isolate->ThrowException(Exception::TypeError(String::NewFromUtf8(isolate, __FUNCTION__":"##tips)));\
		return;\
	}

// base async task impl
class CallbackAsyncTask :public AsyncTask
{
public:
	CallbackAsyncTask()
	{

	}
	virtual ~CallbackAsyncTask()
	{
		LOGI("Collect thread %p\n", mThread);
		mThread->join();
		delete mThread;
		mCallback.Reset();
	}

	thread *mThread;
	Isolate* mIsolate;
	Persistent<Function> mCallback;
};
class BoolenCallbackAsyncTask :public CallbackAsyncTask
{
public:
	BoolenCallbackAsyncTask() :mOK(false)
	{
	}
	~BoolenCallbackAsyncTask()
	{

	}

	int action(void)
	{
		HandleScope scope(mIsolate);

		Local<Value> argv[1];

		argv[0] = v8::Boolean::New(mIsolate, mOK);


		Local<Function> callback = Local<Function>::New(mIsolate, mCallback);
		callback->Call(mIsolate->GetCurrentContext()->Global(), 1, argv);
		return 0;
	}

	bool mOK;
};
class IntergerCallbackAsyncTask :public CallbackAsyncTask
{
public:
	IntergerCallbackAsyncTask() :mRet(-1)
	{
	}
	~IntergerCallbackAsyncTask()
	{

	}

	int action(void)
	{
		HandleScope scope(mIsolate);

		Local<Value> argv[1];

		argv[0] = v8::Number::New(mIsolate, mRet);


		Local<Function> callback = Local<Function>::New(mIsolate, mCallback);
		callback->Call(mIsolate->GetCurrentContext()->Global(), 1, argv);
		return 0;
	}

	int mRet;
};
class CopyInputBuffer
{
public:
	CopyInputBuffer() :mInBuffer(nullptr), mInSize(0)
	{
	}
	virtual ~CopyInputBuffer()
	{
		if (mInBuffer != nullptr)
		{
			delete[] mInBuffer;
		}
	}
	static void freeBuffer(char *mem, void *hit)
	{
		LOGI("Gabbage Collected,%p", mem);
		delete[] mem;
	}
	void setInputBuffe(const char *input, int size)
	{
		lock_guard<mutex> lock(mLock);

		if (mInBuffer != nullptr)
		{
			delete[] mInBuffer;
		}
		if (input != nullptr && size > 0)
		{
			mInSize = size;
			mInBuffer = new char[size];
			memcpy(mInBuffer, input, size);
		}
		else
		{
			mInSize = 0;
			mInBuffer = nullptr;
		}
	}

	char* moveBuffer(int &size)
	{
		lock_guard<mutex> lock(mLock);

		char *ret = mInBuffer;
		size = mInSize;

		mInBuffer = nullptr;
		mInSize = 0;

		return ret;
	}

	char *mInBuffer;
	int mInSize;
	mutex mLock;
};
class BufferAsyncTask :public CallbackAsyncTask
{
public:

	void setBuffer(const char* data, int size)
	{
		mBuffer.setInputBuffe(data, size);
	}
	int action(void)
	{
		HandleScope scope(mIsolate);

		Local<Value> argv[1];
		char *buff;
		int size;

		buff = mBuffer.moveBuffer(size);

		if (size == 0 || buff == nullptr)
		{
			argv[0] = Null(mIsolate);
		}
		else
		{
			argv[0] = Buffer::New(mIsolate, buff, (size_t)size, CopyInputBuffer::freeBuffer, nullptr).ToLocalChecked();
		}

		Local<Function> callback = Local<Function>::New(mIsolate, mCallback);
		callback->Call(mIsolate->GetCurrentContext()->Global(), 1, argv);
		return 0;
	}
private:
	CopyInputBuffer mBuffer;
};
//
void PrintMsg(const FunctionCallbackInfo<Value>& args)
{
	Isolate* isolate = args.GetIsolate();

	CHECK_ARGS_LENGTH(2);
	CHECK_ARGS_IS_STRING(0);
	CHECK_ARGS_IS_FUNCTION(1);

	std::string output(*String::Utf8Value(args[0]));
	
	auto *task = new BoolenCallbackAsyncTask();
	AsyncTaskManager::getSingleton()->addAsyncTask(uv_default_loop(), task);

	Local<Function> callback = Local<Function>::Cast(args[1]);

	task->mIsolate = isolate;
	task->mCallback.Reset(isolate, callback);
	task->mThread = new thread([](BoolenCallbackAsyncTask *task,std::string output) {
		std::cout<<output.c_str()<<std::endl;
		task->mOK = true;
		AsyncTaskManager::getSingleton()->trigerTask(task);
	}, task, output);	
}
void init(Local<Object> exports) {
	NODE_SET_METHOD(exports, "printMsg", PrintMsg);
}

NODE_MODULE($$PROJECT_NAME$$, init)