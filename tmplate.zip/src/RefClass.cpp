/*
   the best way ,Before pass Refclass pointer,do ref() function first
*/
#include "RefClass.hpp"

RefClass::RefClass():mRefCount(1)
{

}

RefClass::~RefClass()
{

}

int RefClass::lock(void)
{
    mLock.Lock();
    return 0;
}

int RefClass::unlock(void)
{
    mLock.UnLock();
    return 0;
}

void RefClass::ref(void)
{
    lock();
    mRefCount++;
    unlock();
}

void RefClass::unref(void)
{
    bool isZeroRef;

    lock();
    if(mRefCount > 0 )
    {
        mRefCount --;
    }
    isZeroRef = (mRefCount == 0);
    unlock();

    if(isZeroRef)
    {
        delete this;
    }
}