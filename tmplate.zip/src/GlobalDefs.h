#ifndef _GLOBAL_DEFS_H__
#define _GLOBAL_DEFS_H__

#include<stdio.h>

//#define DEBUG_INFO

#define LOGE(args,...)	printf("[%s:%d] ",__FUNCTION__,__LINE__);\
						printf(args,##__VA_ARGS__);\
						printf("\n")

#ifdef DEBUG_INFO
#define LOGI(args,...)	printf("[%s:%d] ",__FUNCTION__,__LINE__);\
						printf(args,##__VA_ARGS__);\
						printf("\n")
#else
#define LOGI(args,...)
#endif // printf("\n")


#define ARRAY_SIZE(a)   (sizeof(a)/sizeof((a)[0]))
#define MAX(a,b)		(((a)>(b))?(a):(b))
#define MIN(a,b)		(((a)<(b))?(a):(b))

#define MAX_UNSIGN_SHORT_VALUE	((uint16_t)0xffff)
#define MIN_UNSIGN_SHORT_VALUE	(0)
#define MAX_SIGN_SHORT_VALUE	((int16_t)0x7fff)
#define MIN_SIGN_SHORT_VALUE	((int16_t)0x8000)

#define MAX_UNSIGN_BYTE_VALUE	((uint8_t)0xff)
#define MIN_UNSIGN_BYTE_VALUE	(0)

#define MAX_UNSIGNED_INT32		((uint32_t)0xffffffff)

#define GET_U8(a,k)				(((uint8_t*)(a))[k])
#define UINT16_LITTLE_ENDIA(a)	((uint16_t)GET_U8(a,0)+(((uint16_t)GET_U8(a,1))<<8))
#define INT16_LITTLE_ENDIA(a)	((int16_t)UINT16_LITTLE_ENDIA(a))
#define UINT32_LITTLE_ENDIA(a)	((uint32_t)GET_U8(a,0)+(((uint32_t)GET_U8(a,1))<<8)+(((uint32_t)GET_U8(a,2))<<16)+(((uint32_t)GET_U8(a,3))<<24))
#define INT132_LITTLE_ENDIA(a)	((int32_t)UINT32_LITTLE_ENDIA(a))

#define WRITE_BYTE(v,w,k)			(((uint8_t*)(w))[k]=(uint8_t)((v)&0xff))
#define WRITE_16_LITTLE_ENDIA(v,w)	WRITE_BYTE((v)&0xff,w,0);WRITE_BYTE(((v)>>8)&0xff,w,1)
#define WRITE_32_LITTLE_ENDIA(v,w)  WRITE_BYTE((v)&0xff,w,0);WRITE_BYTE(((v)>>8)&0xff,w,1);WRITE_BYTE(((v)>>16)&0xff,w,2);WRITE_BYTE(((v)>>24)&0xff,w,3)
#endif