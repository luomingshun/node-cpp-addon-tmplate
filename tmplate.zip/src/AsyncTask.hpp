#ifndef __ASYNC_TASK_HPP__
#define __ASYNC_TASK_HPP__

#include <uv.h>
#include <list>
#include "WLock.h"
#include "RefClass.hpp"

using namespace std;

class AsyncTask:public RefClass{
public:
	AsyncTask();
	virtual ~AsyncTask();

	virtual int action(void) = 0;

	uv_async_t mAsync;
	uv_loop_t *mLoop;
};

class AsyncTaskManager{
public:
	
	static AsyncTaskManager* getSingleton();

	void addAsyncTask(uv_loop_t *loop, AsyncTask *task);
	void removeAsyncTask(AsyncTask *task);
	void trigerTask(AsyncTask *task);
	AsyncTask *getAsyncTask(uv_async_t *async);
private:

	AsyncTaskManager();
	virtual ~AsyncTaskManager();

	void removeTaskFromList(AsyncTask *task);

	inline void close_task(AsyncTask *task);

	static void aync_callback(uv_async_t *async);
	static void task_close_cb(uv_handle_t *handle);

	static AsyncTaskManager *mInstance;
	static WLock mLock;

	list<AsyncTask*> mTaskList;
};

#endif