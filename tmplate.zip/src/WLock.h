#ifndef __WLOCK__H__
#define __WLOCK__H__

#include<mutex>

class WLock
{
public:
	WLock();
	virtual ~WLock();
public:
	void UnLock();
	void Lock();

private:
	std::mutex mMutex;
};

class WAutoLock
{
public:
	WAutoLock(WLock* pLock);
	virtual ~WAutoLock();

private:
	WLock*  m_pLock;
};

#endif