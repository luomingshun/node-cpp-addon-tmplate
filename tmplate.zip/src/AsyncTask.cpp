#include "AsyncTask.hpp"
#include "GlobalDefs.h"

AsyncTask::AsyncTask()
{
}
AsyncTask::~AsyncTask()
{
}

WLock AsyncTaskManager::mLock;
AsyncTaskManager *AsyncTaskManager::mInstance = NULL;

AsyncTaskManager* AsyncTaskManager::getSingleton()
{
	WAutoLock auto_lock(&mLock);
	if (mInstance == NULL)
	{
		mInstance = new AsyncTaskManager();
	}

	return mInstance;
}
AsyncTaskManager::AsyncTaskManager()
{
}
AsyncTaskManager:: ~AsyncTaskManager()
{
	LOGI("%s[%p]",__FUNCTION__,this);
	WAutoLock auto_lock(&mLock);
	for (list< AsyncTask*>::iterator it = mTaskList.begin(); it != mTaskList.end(); ++it)
	{
		close_task(*it);
	}
}

void AsyncTaskManager::aync_callback(uv_async_t *async)
{
	AsyncTask * task = AsyncTaskManager::getSingleton()->getAsyncTask(async);
	if (task != NULL)
	{
		if (task->action() == 0)
		{
			AsyncTaskManager::getSingleton()->removeAsyncTask(task);
			task->unref();
		}
	}
	else
	{
		LOGE("Cann't find Async Task[%p]",async);
	}
}
void AsyncTaskManager::task_close_cb(uv_handle_t *handle)
{
	LOGI("Task Closed,hanler->[%p]!", handle);
	AsyncTask *task = AsyncTaskManager::getSingleton()->getAsyncTask((uv_async_t*)handle);
	if(task!=NULL)
	{
		AsyncTaskManager::getSingleton()->removeTaskFromList(task);
		task->unref();
	}
}
AsyncTask *AsyncTaskManager::getAsyncTask(uv_async_t *async)
{
	WAutoLock auto_lock(&mLock);
	AsyncTask *ret = NULL;
	for (list<AsyncTask*>::iterator it = mTaskList.begin(); it != mTaskList.end(); ++it)
	{
		if (&(*it)->mAsync == async)
		{
			ret = *it;
		}
	}

	return ret;
}
void AsyncTaskManager::addAsyncTask(uv_loop_t *loop,AsyncTask *task)
{
	uv_async_init(loop, &task->mAsync, AsyncTaskManager::aync_callback);

	WAutoLock auto_lock(&mLock);
	task->mLoop = loop;
	mTaskList.push_back(task);
}
void AsyncTaskManager::removeTaskFromList(AsyncTask *task)
{
	WAutoLock auto_lock(&mLock);
	mTaskList.remove(task);
}
void AsyncTaskManager::close_task(AsyncTask *task)
{
	if (task->mLoop != NULL)
	{
		LOGI("Will Close Task[%p],hanler->[%p],loop[%p]", task, &task->mAsync, task->mLoop);
		task->ref();
		uv_close((uv_handle_t*)&task->mAsync, AsyncTaskManager::task_close_cb);
		task->mLoop = NULL;
	}
}
void AsyncTaskManager::removeAsyncTask(AsyncTask *task)
{
	WAutoLock auto_lock(&mLock);
	close_task(task);
}
void AsyncTaskManager::trigerTask(AsyncTask *task)
{
	uv_async_send(&task->mAsync);
}
