
type buffer = Uint8Array | Buffer;

declare let $$PROJECT_NAME$$: {
	
}

export default $$PROJECT_NAME$$;